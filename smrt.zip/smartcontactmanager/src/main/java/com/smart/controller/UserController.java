package com.smart.controller;


import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.security.Principal;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.smart.dao.ContactRepository;
import com.smart.dao.UserRepository;
import com.smart.entities.Contact;
import com.smart.entities.User;
import com.smart.helper.message;

import jakarta.servlet.http.HttpSession;


@Controller
@RequestMapping("/user")
public class UserController {
	@Autowired
	private BCryptPasswordEncoder bCryptPassWordEncoder ;
	@Autowired
	private UserRepository  userRepository;
	@Autowired
	private ContactRepository contactRepository;
	
	@ModelAttribute
	public void   addCommonData(Model model,Principal principal) {
		String userName = principal.getName();
		System.out.println("USERNAME"+userName);
		User user = userRepository.getUserByUserName(userName);
		System.out.println("USER"  +user);
		
		model.addAttribute("user",user);
		
	}
	
	@RequestMapping("/index")
	public String dashboard(Model model,Principal principal) {
		
		return "normal/user_dashboard";
	}
	
	@GetMapping("/add-contact")
	public String openAddContactForm(Model model) {
		model.addAttribute("title","Add Contact");
		model.addAttribute("contact",new Contact());
		return "normal/contact_form";
	}
	//process-contact
	@PostMapping("/process-contact")
	public String ProcessContact(@ModelAttribute Contact contact,@RequestParam("imageUrl")MultipartFile file, Principal principal
			,HttpSession session) {
		try {
		String name = principal.getName();
		
		User user = this.userRepository.getUserByUserName(name);
		if(file.isEmpty()) {
			System.out.println("image uploded");
			contact.setImage("contact.png");
		}
		else {
			contact.setImage(file.getOriginalFilename());
			 File file1 = new ClassPathResource("static/img").getFile();
			 Path path = Paths.get(file1.getAbsolutePath()+File.separator+file.getOriginalFilename());
			 Files.copy(file.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);
			System.out.println("image uploded");
		}
		
		contact.setUser(user);
		
		user.getContacts().add(contact);
		
		this.userRepository.save(user);
		
		System.out.println("DATA" +contact);
		System.out.println("add data");
		session.setAttribute("message", new message("Your Contact is Added..!!","success"));
		}catch(Exception e) {
			System.out.println("ERROR"+e.getMessage());
			e.printStackTrace();
			session.setAttribute("message", new message("Something went wrong..!!","danger"));
		}
		return "normal/contact_form";
	}
	     @GetMapping("/show_contacts/{page}")
         public String showContact(@PathVariable("page")Integer page ,Model m,Principal  principal) {
	    	 m.addAttribute("title","show user contacts");
	    	 String userName = principal.getName();
	    	 
	    	 User user = this.userRepository.getUserByUserName(userName);
	    	 PageRequest pageable = PageRequest.of(page, 3);
	    	 Page<Contact> 	contacts  = this.contactRepository.findContactsByUser(user.getId(),pageable);
	    	  m.addAttribute("contacts",contacts);
	    	  m.addAttribute("currentPage",page); 
	    	  m.addAttribute("totalPages",contacts.getTotalPages()); 
        	 return "normal/show_contacts";
         }
	     @RequestMapping("/{cId}/contact")
	     public String ShowContactDetails(@PathVariable("cId") Integer cId,Model model,Principal principal) {
	    	 System.out.println("cid" +cId);
	    	Optional <Contact> contactOptional= this.contactRepository.findById(cId);
	    	 Contact contact = contactOptional.get();
	    	 String userName = principal.getName();
	    	 User user = this.userRepository.getUserByUserName(userName);
	    	 if(user.getId() == contact.getUser().getId())
	    	 model.addAttribute("contact",contact);
	    	 return "normal/contact_details";
	     }
	     @GetMapping("/delete/{cId}")
	     public String deletContact(@PathVariable("cId") Integer cId,Model model,HttpSession session,Principal principal) {
	    	 Contact  contact = this.contactRepository.findById(cId).get();
	    	 User user = this.userRepository.getUserByUserName(principal.getName());
	    	 user.getContacts().remove(contact);
	    	 this.userRepository.save(user);
	    	  //contact.setUser(null);
	    	  
	    	 // this.contactRepository.delete(contact);
	    	  session.setAttribute("message", new message("Your Contact is deleted..!!","success"));
	    	 return"redirect:/user/show_contacts/0";
	     }
	     @PostMapping("/update-contact/{cId}")
	     public String updateForm(@PathVariable("cId") Integer cId,Model m) {
	    	 m.addAttribute("title","Update contact");
	    	 Contact  contact = this.contactRepository.findById(cId).get();
	    	 m.addAttribute("contact",contact);
	    	 return "normal/update_form";
	     }
	     //update handler
	     @RequestMapping(value = "/process-update",method = RequestMethod.POST)
	     public String updateHandler(@ModelAttribute Contact contact,@RequestParam("imageUrl") MultipartFile file,Model m,
	    		 HttpSession session,Principal principal) {
	    	 try {
	    		 Contact oldcontactDetail = this.contactRepository.findById(contact.getcId()).get();
	    		 
	    		 if(!file.isEmpty()) {
	    			 
	    			 //delete photo
	    			 File deletfile = new ClassPathResource("static/img").getFile();
	    			 
	    			 File file2 = new File(deletfile,oldcontactDetail.getImage());
	    			 file2.delete();
	    			 
	    			 
	    			 File file1 = new ClassPathResource("static/img").getFile();
	    			 Path path = Paths.get(file1.getAbsolutePath()+File.separator+file.getOriginalFilename());
	    			 Files.copy(file.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);
                    contact.setImage(file.getOriginalFilename());
	    			 
	    			 
	    			 
	    		 }else {
	    			 contact.setImage(oldcontactDetail.getImage());
	    			 
	    		 }
	    		 User user = this.userRepository.getUserByUserName(principal.getName());
	    		 contact.setUser(user);
	    		 this.contactRepository.save(contact);
	    		 session.setAttribute("message", new message("Your Contact is Updated..!!","success"));
	    		 
	    	 }catch (Exception e) {
	    		 e.printStackTrace();
	    	 }
	    	 System.out.println("CONTACT NAME"+contact.getName());
	    	 return "redirect:/user/"+contact.getcId()+"/contact";
	     }
	     //profile
	     @GetMapping("/profile")
	     public String yourProfile() {
	    	 return "normal/profile";
	     }
	    //open settings
	     @GetMapping("/settings")
	     public String openSettings() {
	    	 return "normal/settings";
	     }
	     @PostMapping("/change-password")
	     public String changePassword(@RequestParam("oldPassword") String oldPassword,@RequestParam("newPassword") String newPassword,
	    		 Principal principal,HttpSession session) {
	    	 String userName = principal.getName();
	    	 User currentUser = this.userRepository.getUserByUserName(userName);
	    	 System.out.println(currentUser.getPassword());
	    	 if(this.bCryptPassWordEncoder.matches(oldPassword, currentUser.getPassword())) {
	    		  currentUser.setPassword(this.bCryptPassWordEncoder.encode(newPassword));
	    		  this.userRepository.save(currentUser);
	    		  session.setAttribute("message", new message("Your Password is Changed..!!","success"));
	    	 }else {
	    		 session.setAttribute("message", new message("Your Old Password is Wrong..!!","danger"));
	    		 return "redirect:/user/settings";
	    	 }
	    	 System.out.println("OLDPASSWORD"+oldPassword);
	    	 System.out.println("NEWPASSWORD"+newPassword);
	    	 
	    	 return "redirect:/user/index";
	     }
	    	
}
